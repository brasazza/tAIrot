//
//  OpenAIService.swift
//  tAIrot
//
//  Created by Brandon Ramírez Casazza on 17/05/23.
//

import Foundation
import Alamofire
import FirebaseRemoteConfig

struct ChatCompletion: Codable {
    let id: String
    let object: String
    let created: Int
    let model: String
    let choices: [Choice]
    
    struct Choice: Codable {
        let message: Message
        let finish_reason: String
        let index: Int
    }
    
    struct Message: Codable {
        let role: String
        let content: String
    }
}

class OpenAIService {
    
    static let shared = OpenAIService()
    private let remoteConfigService = RemoteConfigService.shared
    
    func createChatCompletion(prompt: String, completion: @escaping (Result<String, Error>) -> Void) {
            let apiURL = remoteConfigService.getString(for: "apiURL")
            let headers: HTTPHeaders = [
                "Authorization": remoteConfigService.getString(for: "Authorization"),
                "Content-Type": "application/json"
            ]
            let parameters: Parameters = [
                "model": remoteConfigService.getString(for: "model"),
                "messages": [["role": "user", "content": prompt]]
            ]
        
        AF.request(apiURL, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseDecodable(of: ChatCompletion.self) { response in
                switch response.result {
                case .success(let chatCompletion):
                    if let assistantMessage = chatCompletion.choices.first?.message.content {
                        completion(.success(assistantMessage)) // Removed the card variable here
                    } else {
                        completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No assistant message found in response."])))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}





